#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="/export/home/oracle/aditya/asmdu"
RUNS_ROOT="/nfs/dpz/aditya/runs"

cd "$BASE_DIR"

RUN_DATE=$(date +%F)

/usr/bin/ansible-playbook -f 30 -i inventory.ini collect.yml
/usr/bin/python3 ./build_html_report.py "$RUNS_ROOT" "$RUN_DATE"

echo "DONE. Report: $RUNS_ROOT/$RUN_DATE/report.html"
