#!/bin/bash
# =============================================================================
# run_daily.sh -- ASMDU Daily Cron Wrapper  (hardened)
#
# Improvements over previous version:
#   - Lock file prevents overlapping runs
#   - Pre-flight: NAS writable, asmdu.sh present, ansible reachable
#   - Post-run: counts per-host success/failure from status.txt files
#   - Alert email contains actual critical DG list (not just a count)
#   - Partial failure (some hosts down) exits 0 but emails warning
#   - Full failure exits 1
#   - All output timestamped
# =============================================================================

set -uo pipefail

# =============================================================================
# CONFIGURATION -- edit to match your environment
# =============================================================================
BASE_DIR="/your/deploy/path"
NAS_RUNS_ROOT="/your/nas/runs"
ASMDU_SH="${BASE_DIR}/asmdu.sh"
INVENTORY="${BASE_DIR}/inventory.ini"
PLAYBOOK="${BASE_DIR}/collect.yml"
REPORT_SCRIPT="${BASE_DIR}/build_html_report.py"
PYTHON3="/usr/bin/python3"
ANSIBLE_PLAYBOOK="/usr/bin/ansible-playbook"
LOOKBACK_DAYS=30

LOCK_FILE="/var/lock/asmdu_daily.lock"
LOG_FILE="/var/log/asmdu_daily.log"

# Email settings -- set SEND_EMAIL=true and fill in addresses to enable
SEND_EMAIL=false
EMAIL_TO="dba-team@yourcompany.com"
EMAIL_FROM="asmdu-noreply@yourcompany.com"
MAIL_CMD="mailx"    # or "sendmail", "mutt" etc.

# Alert thresholds for email subject line
EMAIL_CRIT_PCT=85
EMAIL_WARN_PCT=75

# =============================================================================
# SETUP
# =============================================================================
RUN_DATE=$(date +%F)
RUN_TS=$(date +"%Y-%m-%d %H:%M:%S")
LOG_PREFIX="[ASMDU ${RUN_DATE}]"
REPORT_PATH="${NAS_RUNS_ROOT}/${RUN_DATE}/report.html"
CSV_PATH="${NAS_RUNS_ROOT}/${RUN_DATE}/report.csv"

log()  { echo "[$(date '+%H:%M:%S')] ${LOG_PREFIX} $*" | tee -a "${LOG_FILE}" 2>/dev/null || echo "[$(date '+%H:%M:%S')] ${LOG_PREFIX} $*"; }
die()  { log "FATAL: $*"; cleanup_lock; exit 1; }
warn() { log "WARNING: $*"; }

# =============================================================================
# LOCK FILE -- prevent overlapping runs
# =============================================================================
cleanup_lock() { rm -f "${LOCK_FILE}"; }

if [[ -f "${LOCK_FILE}" ]]; then
    existing_pid=$(cat "${LOCK_FILE}" 2>/dev/null || echo "unknown")
    if kill -0 "${existing_pid}" 2>/dev/null; then
        die "Another ASMDU run (PID ${existing_pid}) is still running. Exiting."
    else
        warn "Stale lock file found (PID ${existing_pid} no longer running). Removing."
        rm -f "${LOCK_FILE}"
    fi
fi
echo $$ > "${LOCK_FILE}"
trap cleanup_lock EXIT

# =============================================================================
# PRE-FLIGHT CHECKS
# =============================================================================
log "=== ASMDU Daily Run Starting ==="
log "Run date : ${RUN_DATE}"
log "Base dir : ${BASE_DIR}"
log "NAS root : ${NAS_RUNS_ROOT}"

cd "${BASE_DIR}" || die "Cannot cd to BASE_DIR: ${BASE_DIR}"

[[ -f "${PLAYBOOK}" ]]           || die "Playbook not found: ${PLAYBOOK}"
[[ -f "${INVENTORY}" ]]          || die "Inventory not found: ${INVENTORY}"
[[ -f "${REPORT_SCRIPT}" ]]      || die "Report script not found: ${REPORT_SCRIPT}"
[[ -f "${ASMDU_SH}" ]]           || die "asmdu.sh not found: ${ASMDU_SH}"
[[ -x "${ANSIBLE_PLAYBOOK}" ]]   || die "ansible-playbook not executable: ${ANSIBLE_PLAYBOOK}"
[[ -x "${PYTHON3}" ]]            || die "python3 not executable: ${PYTHON3}"

# NAS mount check -- attempt to write a test file
NAS_TEST="${NAS_RUNS_ROOT}/.asmdu_write_test"
mkdir -p "${NAS_RUNS_ROOT}" 2>/dev/null || die "Cannot create NAS root: ${NAS_RUNS_ROOT}. Is the NAS mounted?"
touch "${NAS_TEST}" 2>/dev/null          || die "NAS root not writable: ${NAS_RUNS_ROOT}. Check mount."
rm -f "${NAS_TEST}"
log "Pre-flight checks passed."

# =============================================================================
# STEP 1 -- ANSIBLE COLLECTION
# =============================================================================
log "Step 1/2: Running Ansible collection playbook..."
ANSIBLE_FORCE_COLOR=0 \
  "${ANSIBLE_PLAYBOOK}" \
  -i "${INVENTORY}" \
  "${PLAYBOOK}" \
  --forks 30 \
  2>&1 | tee -a "${LOG_FILE}" 2>/dev/null || true
PLAYBOOK_RC=${PIPESTATUS[0]}

if [[ ${PLAYBOOK_RC} -ne 0 ]]; then
    warn "Ansible exited RC=${PLAYBOOK_RC}. Some hosts may have failed. Continuing to build report."
fi

# =============================================================================
# POST-COLLECTION HEALTH CHECK
# =============================================================================
TOTAL_HOSTS=0
OK_HOSTS=0
FAIL_HOSTS=0
FAIL_LIST=""

for status_file in "${NAS_RUNS_ROOT}/${RUN_DATE}"/*/status.txt; do
    [[ -f "${status_file}" ]] || continue
    TOTAL_HOSTS=$((TOTAL_HOSTS + 1))
    overall=$(grep "^overall_ok=" "${status_file}" | cut -d= -f2 | tr -d '[:space:]')
    hname=$(grep "^host=" "${status_file}" | cut -d= -f2 | tr -d '[:space:]')
    if [[ "${overall}" == "True" || "${overall}" == "true" ]]; then
        OK_HOSTS=$((OK_HOSTS + 1))
    else
        FAIL_HOSTS=$((FAIL_HOSTS + 1))
        FAIL_LIST="${FAIL_LIST} ${hname}"
    fi
done

log "Collection results: ${TOTAL_HOSTS} hosts | ${OK_HOSTS} OK | ${FAIL_HOSTS} FAILED"
[[ -n "${FAIL_LIST}" ]] && warn "Failed hosts:${FAIL_LIST}"

if [[ ${TOTAL_HOSTS} -eq 0 ]]; then
    die "No host output files found under ${NAS_RUNS_ROOT}/${RUN_DATE}/. Collection completely failed."
fi

# =============================================================================
# STEP 2 -- BUILD REPORT
# =============================================================================
log "Step 2/2: Building HTML report (lookback=${LOOKBACK_DAYS}d)..."

"${PYTHON3}" "${REPORT_SCRIPT}" \
    "${NAS_RUNS_ROOT}" \
    "${RUN_DATE}" \
    --lookback "${LOOKBACK_DAYS}" \
    2>&1 | tee -a "${LOG_FILE}" 2>/dev/null || true
REPORT_RC=${PIPESTATUS[0]}

if [[ ${REPORT_RC} -ne 0 ]]; then
    warn "Report builder failed RC=${REPORT_RC}."
else
    log "HTML report : ${REPORT_PATH}"
    log "CSV export  : ${CSV_PATH}"
fi

# =============================================================================
# STEP 3 -- PARSE CRITICAL ALERTS FOR EMAIL
# =============================================================================
CRIT_LINES=""
WARN_LINES=""
ALERT_COUNT=0

if [[ -f "${CSV_PATH}" ]]; then
    # Read CSV to find critical and warning DGs
    while IFS=',' read -r date host platform dg dg_type redund total used free pct rest; do
        # Skip header
        [[ "${date}" == "date" ]] && continue
        # Remove quotes if present
        pct_clean="${pct//\"/}"
        pct_int=$(echo "${pct_clean}" | cut -d. -f1 2>/dev/null || echo "0")
        if [[ "${pct_int}" -ge "${EMAIL_CRIT_PCT}" ]] 2>/dev/null; then
            CRIT_LINES="${CRIT_LINES}  CRITICAL: +${dg} on ${host}: ${pct_clean}% used\n"
            ALERT_COUNT=$((ALERT_COUNT + 1))
        elif [[ "${pct_int}" -ge "${EMAIL_WARN_PCT}" ]] 2>/dev/null; then
            WARN_LINES="${WARN_LINES}  WARNING:  +${dg} on ${host}: ${pct_clean}% used\n"
            ALERT_COUNT=$((ALERT_COUNT + 1))
        fi
    done < "${CSV_PATH}"
fi

# =============================================================================
# STEP 4 -- EMAIL NOTIFICATION
# =============================================================================
if [[ "${SEND_EMAIL}" == "true" ]]; then
    log "Composing alert email to ${EMAIL_TO}..."

    # Subject severity
    if [[ -n "${CRIT_LINES}" ]]; then
        SUBJECT="[ASMDU][CRITICAL] ASM Capacity Alerts — ${RUN_DATE}"
    elif [[ -n "${WARN_LINES}" ]]; then
        SUBJECT="[ASMDU][WARNING] ASM Capacity Report — ${RUN_DATE}"
    elif [[ ${FAIL_HOSTS} -gt 0 ]]; then
        SUBJECT="[ASMDU][PARTIAL FAILURE] ${FAIL_HOSTS} host(s) failed collection — ${RUN_DATE}"
    else
        SUBJECT="[ASMDU][OK] ASM Capacity Report — ${RUN_DATE}"
    fi

    BODY="ASMDU Daily Capacity Report
Generated : ${RUN_TS}
Report    : ${REPORT_PATH}
CSV       : ${CSV_PATH}

Collection Summary:
  Hosts total   : ${TOTAL_HOSTS}
  Hosts OK      : ${OK_HOSTS}
  Hosts FAILED  : ${FAIL_HOSTS}
  Playbook RC   : ${PLAYBOOK_RC}
  Report RC     : ${REPORT_RC}
"
    if [[ -n "${CRIT_LINES}" ]]; then
        BODY="${BODY}
CRITICAL DISKGROUPS (immediate action required):
$(printf "%b" "${CRIT_LINES}")"
    fi
    if [[ -n "${WARN_LINES}" ]]; then
        BODY="${BODY}
WARNING DISKGROUPS:
$(printf "%b" "${WARN_LINES}")"
    fi
    if [[ -n "${FAIL_LIST}" ]]; then
        BODY="${BODY}
FAILED HOSTS (no data collected):${FAIL_LIST}
"
    fi
    BODY="${BODY}
Open the HTML report for full details including growth trends and capacity projections.
"

    echo "${BODY}" | ${MAIL_CMD} -s "${SUBJECT}" \
        -r "${EMAIL_FROM}" \
        "${EMAIL_TO}" 2>/dev/null \
        && log "Email sent to ${EMAIL_TO}" \
        || warn "Email delivery failed (non-fatal). Check ${MAIL_CMD} configuration."
fi

# =============================================================================
# DONE
# =============================================================================
log "=== ASMDU Daily Run Complete ==="
log "Playbook RC=${PLAYBOOK_RC} | Report RC=${REPORT_RC} | Hosts OK=${OK_HOSTS}/${TOTAL_HOSTS} | Alerts=${ALERT_COUNT}"

# Exit 1 only if report itself failed (data is useless)
[[ ${REPORT_RC} -ne 0 ]] && exit 1
exit 0
